---
sidebar_position: 1
---

# Project Plan

## Objective

Create a platform to post projects for Binusian.

* Project submission is private for Binusian only
* Guest can see and react to the projects

The website will increase the position of binusians on people knowing about the projects that is created on Binus.


